.. image:: https://badge.fury.io/py/pwbs.svg
    :target: https://badge.fury.io/py/pwbs
.. image:: https://img.shields.io/pypi/l/pwbs.svg
.. image:: https://img.shields.io/pypi/wheel/pwbs.svg
.. image:: https://img.shields.io/pypi/format/pwbs.svg
.. image:: https://img.shields.io/pypi/implementation/pwbs.svg
.. image:: https://img.shields.io/pypi/pyversions/pwbs.svg
.. image:: https://img.shields.io/pypi/status/pwbs.svg
.. image:: https://img.shields.io/pypi/v/pwbs.svg
    :target: https://pypi.org/project/pwbs/
.. image:: https://readthedocs.org/projects/pwbs/badge/?version=latest
    :target: http://pwbs.readthedocs.io/en/latest/?badge=latest

PAiP Web Build System
=====================

Actual Version : v.0.4.0-dev1
By Project Rewrite and Rethink Dev 2.0 use pwbs==0.3.0.dev1 for any purpose. Actual version use only when you want to help developers.

PWBS is Build System for easy automation process.


* Free software: MIT license
* PyPi Package: https://pypi.python.org/pypi/pwbs/ or https://pypi.org/project/pwbs/

Features
--------

* TODO: Working on it

Credits
---------

Created by Patryk Adamczyk
