Welcome to PWBS's documentation!
================================

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. include:: ../../README.rst

.. include:: ../../HISTORY.rst

.. include:: ../../CONTRIBUTING.rst

.. include:: ../../AUTHORS.rst

.. include:: code_auto_documentation.rst

