pwbs.config
-----------

.. py:module:: pwbs.config

This module is place of configuration classes and loading configuration classes.