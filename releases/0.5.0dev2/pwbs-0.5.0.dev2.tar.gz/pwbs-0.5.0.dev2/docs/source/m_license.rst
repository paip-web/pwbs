=======
License
=======

**************************
Informations about license
**************************

License: **MIT**

Copyright: **Patryk Adamczyk © 2017-2019**

************
License Text
************

.. include:: ../../LICENSE
