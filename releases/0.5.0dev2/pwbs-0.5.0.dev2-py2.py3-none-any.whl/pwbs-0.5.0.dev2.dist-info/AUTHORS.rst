Credits
=======

Development Lead
----------------

* Patryk Adamczyk <patrykadamczyk@patrykadamczyk.net>

Contributors
------------

* Mateusz Barański <mateusbaranski@gmail.com>
