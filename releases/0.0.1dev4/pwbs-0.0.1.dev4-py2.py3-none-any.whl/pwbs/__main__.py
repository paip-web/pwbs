import sys
from .__init__ import main

if __name__ == '__main__':# or __name__ == 'pwbs':
    sys.exit(main(sys.argv))
else:
    sys.exit(main(sys.argv))
