# -*- coding: utf-8 -*-
"""PAiP Web Build System

NAME - PAiP Web Build System
AUTHOR - Patryk Adamczyk <patrykadamczyk@paipweb.com>
LICENSE - MIT

"""
# Underscore Variables
__author__ = 'Patryk Adamczyk'
__license__ = 'MIT'
__docformat__ = 'restructuredtext en'
