pwbs.core
---------

.. py:module:: pwbs.core

This module is place for PWBS core things like exceptions.

.. py:function:: prefix_text(text="")

    Default Prefixer

.. py:exception:: NotImplementedFeatureError()

    Error for Not Implemented Functionality