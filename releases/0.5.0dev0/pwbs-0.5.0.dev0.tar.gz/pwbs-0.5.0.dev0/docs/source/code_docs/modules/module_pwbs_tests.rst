pwbs.tests
----------

.. py:module:: pwbs.tests

This module is place for tests.
This module will be documented together (In 2 parts: first about test runner and second about all tests).