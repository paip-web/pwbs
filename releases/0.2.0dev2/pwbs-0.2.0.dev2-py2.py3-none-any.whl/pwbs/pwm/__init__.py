__title__ = 'pwm'
__version__ = '0.0.1'
__author__ = 'Patryk Adamczyk'
__license__ = 'MIT'
