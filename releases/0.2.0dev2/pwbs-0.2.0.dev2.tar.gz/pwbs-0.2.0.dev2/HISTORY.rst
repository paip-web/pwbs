History
=======

0.2.0-dev2 (16.12.2017)
-----------------------

* Release 7 on PyPi
* Repaired RST Errors

0.2.0-dev1 (16.12.2017)
-----------------------

* Release 6 on PyPi
* Added Signle Tasking

0.1.0-dev2 (13.12.2017-16.12.2017)
----------------------------------

* Release 5 on PyPi
* Added --new-config option as Working
* Added --config <file> option as Working

0.1.0-dev1 (12.12.2017-13.12.2017)
----------------------------------

* Release 4 on PyPi
* Added collective.checkdocs as setup requirement
* Repaired RST Errors
* Tests for pwm submodule and for pwbs module

0.0.1-dev4 (09.12.2017-12.12.2017)
----------------------------------

* Release 3 on PyPi
* Adding Command Interpreter
* Repairing setup.py Script
* Added Tox as Test Runner for checking with which version pwbs is compatible
* Added Command --help
* Added Command --verbose <mode>

0.0.1-dev3 (09.12.2017)
-----------------------

* Release 2 on PyPi
* Adding Baner

0.0.1-dev2 (09.12.2017)
-----------------------

* First Release in PyPi

0.0.1-dev0 (09.12.2017)
-----------------------

* First packaging
