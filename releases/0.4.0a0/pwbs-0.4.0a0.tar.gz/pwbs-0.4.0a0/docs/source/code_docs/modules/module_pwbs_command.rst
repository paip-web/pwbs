pwbs.command
------------

.. py:module:: pwbs.command

This module is place for Commands Classes.
Commands classes are used to interpret config into objects and by that they can invoke run method which runs commands which was specified in config file.