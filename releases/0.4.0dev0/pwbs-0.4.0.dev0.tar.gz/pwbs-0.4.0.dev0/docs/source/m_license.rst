=======
License
=======

**************************
Informations about license
**************************

License: **MIT**

Copyright: **Patryk Adamczyk © 2017-2018**

************
License Text
************

.. include:: ../../LICENSE