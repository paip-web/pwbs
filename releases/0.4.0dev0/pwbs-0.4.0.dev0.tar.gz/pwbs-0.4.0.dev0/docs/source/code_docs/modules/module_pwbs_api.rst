pwbs.api
--------

.. py:module:: pwbs.api

This module is place for future api to make plugins for PWBS.