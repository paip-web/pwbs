pwbs.lib
--------

.. py:module:: pwbs.lib

This module is place for all dependencies which are made as part of PWBS for no dependencies version complications.
This module will not be ever well documented here because of type of files it has.