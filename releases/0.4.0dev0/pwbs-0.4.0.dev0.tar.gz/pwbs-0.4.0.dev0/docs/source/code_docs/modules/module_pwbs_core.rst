pwbs.core
---------

.. py:module:: pwbs.core

This module is place for core PWBS features.

.. TODO: Here PWBS should have all Exceptions