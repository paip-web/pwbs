.. image:: https://badge.fury.io/py/pwbs.svg
    :target: https://badge.fury.io/py/pwbs
.. image:: https://img.shields.io/pypi/l/pwbs.svg
.. image:: https://img.shields.io/pypi/wheel/pwbs.svg
.. image:: https://img.shields.io/pypi/format/pwbs.svg
.. image:: https://img.shields.io/pypi/implementation/pwbs.svg
.. image:: https://img.shields.io/pypi/pyversions/pwbs.svg
.. image:: https://img.shields.io/pypi/status/pwbs.svg
.. image:: https://img.shields.io/pypi/v/pwbs.svg
    :target: https://pypi.org/project/pwbs/

PAiP Web Build System
=====================

Actual Version : v.0.1.0-dev1
PWBS is Build System for easy automation process.


* Free software: MIT license
* PyPi Package: https://pypi.python.org/pypi/pwbs/ or https://pypi.org/project/pwbs/

Features
--------

* TODO: Working on it

Credits
---------

Created by Patryk Adamczyk


History
=======

0.1.0-dev1 (12.12.2017)
-----------------------

* Release 4 on PyPi
* Added collective.checkdocs as setup requirement
* Repaired RST Errors
* Tests for pwm submodule and for pwbs module

0.0.1-dev4 (09.12.2017-12.12.2017)
----------------------------------

* Release 3 on PyPi
* Adding Command Interpreter
* Repairing setup.py Script
* Added Tox as Test Runner for checking with which version pwbs is compatible
* Added Command --help
* Added Command --verbose <mode>

0.0.1-dev3 (09.12.2017)
-----------------------

* Release 2 on PyPi
* Adding Baner

0.0.1-dev2 (09.12.2017)
-----------------------

* First Release in PyPi

0.0.1-dev0 (09.12.2017)
-----------------------

* First packaging


