==================
Roadmap to FUTURE:
==================

*************
Core Features
*************

* Multi Tasks
* Watcher Tasks
* Scheduler Tasks
* Argumented Tasks

********
Features
********

* Server Mode
    
    * PWBS is making little server with interface by which can be executed tasks and you can see output afterwards by that interface.

* Python PWBS API

    * Making availble some functions as PWBS API in Python.
    
    * Plugins written in Python to extend PWBS.

* Special Integrated Tasks PWBS API

    * Making availble some special tasks as PWBS API in JSON.

    * Plugins written in JSON to extend PWBS.

* Better Logging

* Make use of verbose_mode and debug_mode (and test_mode(255,True) too)

* Better Logging Levels

* Global Configuration File (Or Local User Configuration File)

* Better STDOUT with colorama or something

* Better and more tests