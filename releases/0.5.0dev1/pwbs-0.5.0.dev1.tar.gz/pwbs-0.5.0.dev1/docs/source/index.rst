================================
Welcome to PWBS's documentation!
================================

*********************
PAiP Web Build System
*********************

Actual Version : v.0.4.0-dev0
-----------------------------
.. image:: https://badge.fury.io/py/pwbs.svg
    :target: https://badge.fury.io/py/pwbs
.. image:: https://img.shields.io/pypi/l/pwbs.svg
.. image:: https://img.shields.io/pypi/wheel/pwbs.svg
.. image:: https://img.shields.io/pypi/format/pwbs.svg
.. image:: https://img.shields.io/pypi/implementation/pwbs.svg
.. image:: https://img.shields.io/pypi/pyversions/pwbs.svg
.. image:: https://img.shields.io/pypi/status/pwbs.svg
.. image:: https://img.shields.io/pypi/v/pwbs.svg
    :target: https://pypi.org/project/pwbs/
.. image:: https://readthedocs.org/projects/pwbs/badge/?version=latest
    :target: http://pwbs.readthedocs.io/en/latest/?badge=latest

******************
Indices and tables
******************

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


.. toctree::
   :maxdepth: 10
   :caption: Contents:
   :glob:

   *


